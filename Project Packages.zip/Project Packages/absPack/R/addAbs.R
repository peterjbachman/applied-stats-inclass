addAbs <-
function(x, y){
    return(list(square=(abs(x) + abs(y)), x = x, y = y))
}
